import sys, os
sys.path.insert(1, os.path.join(sys.path[0], '..'))

from dfa.dfa import DFA
# from nfa.nfa import NFA

dfa = DFA('automaton.cfg')
test(dfa.accepts_input('string_1.in') == parse('string_1.out'))

nfa = NFA('automaton.cfg')
test(dfa.accepts_input('string_1.in') == parse('string_1.out'))
