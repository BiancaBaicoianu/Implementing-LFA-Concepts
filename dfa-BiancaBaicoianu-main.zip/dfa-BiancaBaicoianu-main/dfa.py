import sys

class DFA:

    def __init__(self, states, sigma, transitions, start_state, final_state, current_state):
        self.states = states
        self.sigma = set(sigma)
        self.transitions = transitions
        self.start_state = start_state
        self.final_state = final_state
        self.current_state = start_state
        return

    def validate(self, input_str):
        current_state = self.start_state

        for inp in input_str:
            try:
                if inp in self.transitions[current_state]:
                    current_state = self.transitions[current_state][inp]
                else:
                    return False
            except KeyError as error:
                return False

        if current_state in self.accept_states:
            return True

        return False


    def accepts_input(self, input_str):
        self.current_state = self.start_state
        for inp in input_str:
            if (self.current_state, inp) not in self.transitions.keys():
                self.current_state = None
                # return
            self.current_state = self.transitions[(self.current_state, inp)]
            # return
            continue
        if self.validate(input_str):
            print("Accepted")
        else:
            print("Rejected")

    pass


class Automaton:

    def __init__(self, config_file):
        self.config_file = config_file
        print("Hi, I'm an automaton!")

        self.sigma = []
        self.states = []
        self.transitions = []
        Automaton = dict()

        with open(self.config_file) as f:
            # Sigma:
            # word1
            # word2
            # ...
            # End
            line = f.readline().strip()  # citim prima linie din fisier pana ajungem la "end"
            while line.lower() != "end":
                # daca avem randuri comentate, "...", citim urmatoarea linie si iesim din while
                if line[0] == '#' or ("..." in line) or (":" in line):
                    line = f.readline().strip()
                    continue
                else:
                    # altfel, adaugam noua sigma si citim urmatorul rand
                    self.sigma.append(line)
                    line = f.readline().strip()

            # States:
            # state1
            # state2
            # state3, F
            # ...
            # stateK, S
            # ...
            # End
            line = f.readline().strip()
            while line.lower() != "end":
                if line[0] == '#' or ("..." in line) or (":" in line):
                    line = f.readline().strip()
                    continue
                else:
                    tuplu = line.split(",")
                    tuplu[0] = tuplu[0].strip()
                    if len(tuplu) > 1:
                        tuplu[1] = tuplu[1].strip()
                        if len(tuplu) > 2:
                            tuplu[2] = tuplu[2].strip()
                    self.states.append(tuplu)
                    line = f.readline().strip()

            # Transitions:
            # stateX, wordY, stateZ
            # stateX, wordY, stateZ
            # ...
            # End
            line = f.readline().strip()
            while line.lower() != "end":
                if line[0] == "#" or ("..." in line) or (":" in line):
                    line = f.readline().strip()
                    continue
                else:
                    aux = line.split(",")
                    aux[0], aux[1], aux[2] = aux[0].strip(), aux[1].strip(), aux[2].strip()
                    # self.transitions.append(aux)
                    # self.transitions[(aux[0], aux[1])] = aux[2]
                    self.transitions.append(aux)
                    line = f.readline().strip()


        Automaton = {"Sigma": self.sigma, "Stari": self.states, "Tranzitii": self.transitions}
        # for key in Automaton.keys():
        #     print(key, "->", Automaton[key])

    def validate(self):
        init_fin = []
        for s in self.states:
            if len(s) > 2:
                init_fin.append((s[1], s[2]))
            elif len(s) > 1:
                init_fin.append(s[1])
            else:
                init_fin.append("")

        #”S” symbol can succeed only one state.
        if init_fin.count("S") > 1:
            print("Only one starting state allowed!")

        for tr in self.transitions.keys():
            accept_states = [state[0] for state in self.states]
            # if transition[0] not in accept_states or transition[2] not in accept_states or transition[1] not in self.sigma:
            aux1, aux2 = tr
            if self.transitions[tr] not in accept_states or aux1 not in accept_states or aux2 not in self.sigma:
                raise Exception("Invalid words or states!")
        return True, init_fin

    def ret_sigma(self):
        return self.sigma

    def ret_states(self):
        return self.states

    def ret_transitions(self):
        return self.transitions

    def create_transitions(self):
        aux = {tuple([t[0].strip(), t[1].strip()]): t[2].strip() for t in self.transitions}
        return aux

if __name__ == "__main__":

    num_args = len(sys.argv)
    if num_args > 1:
        print(f"I see you provided {num_args - 1} argument{'s' if num_args > 2 else ''} from the console.")
        print("Here's a list with all the system arguments:")
        for i, arg in enumerate(sys.argv):
            print(f"Argument {i}: {arg:>32}")
        print()

    a = Automaton("dfa_config_file.txt")
    states = a.ret_states()
    sigma = a.ret_sigma()
    tranz = a.ret_transitions()

    for s in states:
        if len(s) == 2:
            if s[1] == 'S':
                start_state = s[0]
            elif s[1] == 'F':
                final_state = s[0]
        elif len(s) == 3:
            start_state = s[0]
            final_state = s[0]

    transitions = a.create_transitions()

    dfa = DFA(tuple(states), sigma, transitions, start_state, final_state, None)

    with open("input_string.txt") as input:
        input_str = input.readline().strip()
        dfa.validate(input_str)
        print(dfa.accepts_input(input_str))
