[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7412158&assignment_repo_type=AssignmentRepo)
# dfa

### Second LFA Lab
Exercise 1. Implement a library/program in a programming language of your
choosing that creates a DFA. Use your library from lab 1 to generate the DFA
based on input file. Then check of DFA accepts a give string. Allow command
line arguments to your program in the form:
```
your_dfa_engine.py  dfa_config_file  input_string
>> a c c e p t / r e j e c t
```

Exercise 2. Create configuration files for DFAs from Exercises 1.5 and 1.6
(Sipser - Chapter 1).
