
def parse(state, word):         #recursiv (parcurgere in adancime)
    global valid
    c_word = word
    for i in range(states):
        if len(m[state][i])!=0 and ( word[0] in m[state][i]) :
            word = word[1:] #sterg primul caracter
            if len(word)==0:
                if i in finale_states:
                    valid = 1
                return
            parse(i, word)
            word = c_word


with open("nfa_config_file.txt") as input_file:
    states = int(input_file.readline()) #numarul total de stari
    start_state = int(input_file.readline()) #starea initiala
    finale_states = [int(x) for x in input_file.readline().split()]
    nrtranz = int(input_file.readline()) #nr tranzitii
    m = [] #matricea grafului
    for i in range (states):
        M = []
        for j in range (states):
            M.append([])
        m.append(M)
    for i in range(nrtranz): #tranzitii
        transition = input_file.readline().strip()
        tr = transition.split()
        m[int(tr[0])][int(tr[2])].append(tr[1])
    word = input_file.readline() #cuvant

# $ cuvantul vid
if word == '$' and start_state in finale_states: #cuvantul vid
    print("Accepted")
else:
    valid = 0
    parse(start_state, word)
    if valid == 0:
        print("Rejected")
    else:
        print("Accepted")


